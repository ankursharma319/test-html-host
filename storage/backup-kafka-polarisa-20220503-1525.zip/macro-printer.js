import xapi from 'xapi';

async function main() {
  console.log('Fetching system name...');
  const who = await xapi.Config.SystemUnit.Name.get();
  const internConf = await xapi.Config.UserInterface.Features.HideAll.get();
  console.log(`Hello, ${who}! ${internConf}`);
}

main();

